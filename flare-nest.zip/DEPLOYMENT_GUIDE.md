# Deployment & Configuration Guide

## 🚀 Deployment Options

Your app is ready to deploy! Choose your preferred platform:

### Option 1: Vercel (Recommended) ⭐

**Why Vercel?**
- Automatic deployments from Git
- Zero-configuration setup
- Serverless functions support
- Analytics built-in
- Free tier available

**Steps:**

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Select your GitHub repository
   - Click "Import"

3. **Configure**
   - Framework: Vite
   - Root Directory: ./
   - Build Command: `npm run build`
   - Output Directory: `dist`

4. **Deploy**
   - Click "Deploy"
   - Your app is live!

**Future Deployments:**
- Every push to main automatically deploys
- Staging URLs for PRs

---

### Option 2: Netlify

**Steps:**

1. **Build Locally**
   ```bash
   npm run build
   ```

2. **Connect to Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Click "New site from Git"
   - Select GitHub
   - Choose your repository

3. **Configure Build Settings**
   - Build command: `npm run build`
   - Publish directory: `dist`

4. **Deploy**
   - Click "Deploy site"
   - Site is live!

**Netlify Configuration File** (`netlify.toml`):
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[context.production]
  environment = { NODE_ENV = "production" }
```

---

### Option 3: Docker

**Dockerfile:**
```dockerfile
# Build stage
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Production stage
FROM node:18-alpine
WORKDIR /app
RUN npm install -g serve
COPY --from=builder /app/dist dist
EXPOSE 3000
CMD ["serve", "-s", "dist", "-l", "3000"]
```

**Build & Run:**
```bash
# Build image
docker build -t khrga-app .

# Run container
docker run -p 3000:3000 khrga-app

# Visit http://localhost:3000
```

---

### Option 4: Traditional Server (Node.js)

**1. Setup Server**
```bash
# On your server
sudo apt update
sudo apt install nodejs npm

# Clone repository
git clone <your-repo-url>
cd <project>
npm install
```

**2. Build Application**
```bash
npm run build
```

**3. Install PM2 (Process Manager)**
```bash
npm install -g pm2
```

**4. Start Application**
```bash
pm2 start "npm start" --name "khrga-app"
pm2 startup
pm2 save
```

**5. Setup Nginx Reverse Proxy**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_cache_bypass $http_upgrade;
    }
}
```

**6. Enable HTTPS with Let's Encrypt**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

---

## 🔧 Configuration

### Environment Variables

Create `.env.local` for local development:
```env
VITE_API_URL=http://localhost:3000/api
VITE_APP_NAME=خرجة
VITE_APP_VERSION=1.0.0
```

Create `.env.production` for production:
```env
VITE_API_URL=https://api.khrga.app
VITE_APP_NAME=خرجة
VITE_APP_VERSION=1.0.0
```

### Vite Configuration

The app uses Vite with the following configuration:
- SSR: Disabled (SPA mode)
- Build output: `dist/`
- Development port: 5173
- Production build: Optimized with code splitting

---

## 📊 Build Optimization

### Bundle Analysis

```bash
# Analyze build size
npm install -g vite-plugin-visualizer
# Then add to vite.config.ts and rebuild
```

### Production Build

```bash
npm run build

# Output will be in dist/
# Gzip compression: ~50-80KB
```

### Performance Metrics

Target metrics:
- **First Contentful Paint (FCP)**: < 1.5s
- **Largest Contentful Paint (LCP)**: < 2.5s
- **Time to Interactive (TTI)**: < 3.5s
- **Cumulative Layout Shift (CLS)**: < 0.1

---

## 🔒 Security Checklist

Before deployment:

- [ ] Remove console.log statements
- [ ] Enable HTTPS only
- [ ] Set security headers
- [ ] Enable CORS properly
- [ ] Validate all user inputs
- [ ] Use environment variables for secrets
- [ ] Enable rate limiting
- [ ] Setup monitoring
- [ ] Regular security audits
- [ ] Keep dependencies updated

### Security Headers (Nginx)

```nginx
add_header Strict-Transport-Security "max-age=31536000" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self' https:" always;
```

---

## 📈 Monitoring & Analytics

### Website Analytics

**Google Analytics:**
```typescript
// In main.tsx or App.tsx
import ReactGA from 'react-ga4';

ReactGA.initialize('GA_ID');
ReactGA.send({ hitType: 'pageview', page: window.location.pathname });
```

**Custom Events:**
```typescript
const trackEvent = (category, action, label) => {
  ReactGA.event({
    category,
    action,
    label,
  });
};
```

### Error Monitoring

**Sentry Setup:**
```typescript
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: process.env.NODE_ENV,
});

export default Sentry.withProfiler(App);
```

---

## 🧪 Pre-Deployment Checklist

### Code Quality
- [ ] No TypeScript errors: `npm run typecheck`
- [ ] No linting errors: `npm run lint`
- [ ] Tests passing: `npm run test`
- [ ] Build succeeds: `npm run build`

### Functionality
- [ ] All pages load correctly
- [ ] Navigation works
- [ ] Forms submit correctly
- [ ] No console errors
- [ ] Responsive design verified
- [ ] Mobile tested

### Performance
- [ ] Images optimized
- [ ] Bundle size acceptable
- [ ] Load time < 3s
- [ ] No N+1 queries

### Security
- [ ] No hardcoded secrets
- [ ] Environment variables set
- [ ] HTTPS enabled
- [ ] Security headers configured

---

## 🚨 Troubleshooting

### Build Issues

**Problem:** Build fails with "Module not found"
```bash
# Solution
npm ci  # Clean install
npm run build
```

**Problem:** Tailwind classes not applied
```bash
# Solution: Check tailwind.config.ts content paths
# Ensure all .{ts,tsx} files are in content array
```

### Deployment Issues

**Problem:** White blank page after deployment
```bash
# Solution: Check browser console for errors
# Verify VITE_APP_URL is set correctly
# Check GitHub Pages isn't trying to use Jekyll
```

**Problem:** Styling missing after deployment
```bash
# Solution: Ensure CSS files are in dist/
# Check server is serving static files correctly
# Verify asset paths are correct
```

---

## 📋 Deployment Checklist (Copy & Paste)

```markdown
## Pre-Deployment

- [ ] Code reviewed
- [ ] TypeScript check passed
- [ ] Tests passing
- [ ] Build successful
- [ ] No console errors/warnings
- [ ] Environment variables configured
- [ ] API endpoints working
- [ ] Database migrations applied

## Deployment

- [ ] Deploy to staging
- [ ] Test on staging environment
- [ ] Performance test
- [ ] Security test
- [ ] Deploy to production
- [ ] Monitor error logs
- [ ] Check analytics

## Post-Deployment

- [ ] Verify site loads
- [ ] Test main features
- [ ] Check analytics
- [ ] Monitor performance
- [ ] Setup alerts
- [ ] Document deployment
```

---

## 📞 Deployment Support

**Common Deployment Errors:**

| Error | Solution |
|-------|----------|
| `ENOENT: no such file or directory` | Run `npm install` |
| `Module not found` | Check import paths, run `npm ci` |
| `Port already in use` | Change port in config or kill process |
| `Out of memory` | Increase Node memory: `NODE_OPTIONS=--max_old_space_size=4096` |

---

## 🎯 Production Readiness

Your app is production-ready when:

✅ All features implemented
✅ Tests passing
✅ No console errors
✅ Performance optimized
✅ Security checked
✅ Documentation complete
✅ Monitoring setup
✅ Backup strategy defined
✅ Recovery plan documented
✅ Team trained

---

## 🔄 CI/CD Pipeline

### GitHub Actions Example

```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run typecheck
      - run: npm run build
      - uses: actions/upload-artifact@v3
        with:
          name: dist
          path: dist/
```

---

## 📚 Additional Resources

- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html)
- [Vercel Docs](https://vercel.com/docs)
- [Netlify Docs](https://docs.netlify.com)
- [Docker Docs](https://docs.docker.com)
- [Node.js Best Practices](https://nodejs.org/en/docs/guides/)

---

**Congratulations! Your app is ready for production! 🎉**

---

*Version: 1.0.0*
*Last Updated: 2024*
