# خرجة (Khrga) - Discovery App for Egyptian Places

A luxurious, modern Egyptian-themed mobile web application for discovering and exploring places in Egypt. Built with React, TypeScript, and TailwindCSS with a stunning Egyptian aesthetic.

## 🎯 Features

### 1. **Places Discovery (الأماكن)**
- Beautiful grid view of recommended places
- Smart filtering by category (historical, food, nature, culture, shopping)
- Real-time search functionality
- Place cards with images, ratings, distances, and pricing
- Favorites/wishlist functionality
- Floating action button (Pharaonic artifact design)
- Pull-to-refresh with Eye of Ra animation

### 2. **Smart Chat Assistant (شات الذكي)**
- Conversational AI-powered recommendations
- Context-aware suggestions based on mood, budget, and weather
- Quick suggestion buttons
- Real-time chat interface
- Voice support ready (with Mic button)
- Egyptian Arabic language support

### 3. **Advanced Explore (استكشاف)**
- Comprehensive search with advanced filtering
- Filter by:
  - Category (Historical, Food, Nature, Culture, Shopping)
  - Price Range (Low, Medium, High)
  - Rating (3+, 4+, 4.5+)
  - Distance (Near, Medium, Far)
- List view with detailed information
- Quick action buttons

### 4. **Place Details (تفاصيل المكان)**
- Image gallery with swipeable interface
- Comprehensive place information
- Hours of operation
- Contact information
- User reviews and ratings
- Available activities
- Booking and directions buttons

### 5. **User Profile (ملفي الشخصي)**
- User information and stats
- Preferences management
- Saved favorites
- Recent visit history
- Account settings
- Logout functionality

### 6. **Smart Navigation**
- Bottom navigation bar with all major sections
- Active state indicators with golden highlights
- Smooth transitions between pages
- Mobile-optimized design

## 🎨 Design System

### Color Palette
- **Gold (Pharaonic Gold)**: `#D4AF37` - Primary accent color
- **Black (Deep Egyptian)**: `#000000` - Headers and dark backgrounds
- **Cream/Beige**: `#F9F6F0` - Background gradient
- **White**: `#FFFFFF` - Card backgrounds
- **Tan**: `#E8DCC4` - Secondary background tint

### Typography
- **Font**: Cairo (Arabic) + Inter (Fallback)
- **Weights**: 400 (Regular), 600 (Semibold), 700 (Bold), 800 (Extra Bold)

### Animations
- Fade In Up: Staggered entry animation for cards
- Scale on Hover: Smooth hover effects
- Pulse Gold: Floating button glow effect
- Hero Zoom: Image zoom on interaction
- Scroll Reveal: Progressive content reveal

### Components
- **PlaceCard**: Display individual place with image, rating, and details
- **BottomNav**: Global navigation between major sections
- **SmartFilter**: Category/filter selection
- **AIRecommendationWidget**: Featured AI suggestion box
- **FloatingButton**: Pharaonic artifact-shaped action button

## 🛠 Tech Stack

### Frontend
- **React 18** - UI framework
- **React Router 6** - Client-side routing
- **TypeScript** - Type safety
- **Tailwind CSS 3** - Utility-first styling
- **Vite** - Build tool and dev server
- **Lucide React** - Icon library
- **React Query** - Data fetching (optional)

### Styling Features
- Custom CSS Grid layouts
- Gradient backgrounds
- Responsive design (mobile-first)
- Safe area insets for notched devices
- Dark mode support (built-in)

## 📱 Pages & Routes

| Route | Component | Description |
|-------|-----------|-------------|
| `/` | Index.tsx | Main Places discovery page |
| `/places` | Index.tsx | Same as home (alt route) |
| `/place/:id` | PlaceDetail.tsx | Individual place details |
| `/explore` | Explore.tsx | Advanced search with filters |
| `/chat` | Chat.tsx | Smart chat assistant |
| `/profile` | Profile.tsx | User profile & settings |

## 🚀 Getting Started

### Installation
```bash
# Install dependencies
npm install
# or
pnpm install
```

### Development
```bash
# Start dev server
npm run dev
# or
pnpm dev
```

### Build
```bash
# Production build
npm run build
# or
pnpm build
```

### Start Production Server
```bash
npm start
# or
pnpm start
```

## 📂 Project Structure

```
client/
├── pages/
│   ├── Index.tsx          # Main Places page
│   ├── PlaceDetail.tsx    # Place details view
│   ├── Chat.tsx           # Chat assistant
│   ├── Explore.tsx        # Advanced search
│   ├── Profile.tsx        # User profile
│   └── NotFound.tsx       # 404 page
├── components/
│   └── BottomNav.tsx      # Navigation component
├── App.tsx                # Main app with routing
├── global.css             # Global styles & theme
└── vite-env.d.ts          # Vite env types

tailwind.config.ts        # Tailwind configuration
```

## 🎯 Key Features Implementation

### Smart Filters
Located in header with dynamic category selection:
- Highlights active filter with gold background
- Smooth scrolling horizontal layout
- Real-time filtering of results

### AI Recommendation Widget
- Featured in home page
- Dark background with gold border
- Egyptian pattern corners
- Contextual suggestion text with user mood
- Emoji support for visual appeal

### Place Cards
- Hoverable with scale-up effect
- Image with gradient overlay
- Bold gold text on dark background
- Quick favorite toggle
- Details button navigation

### Navigation
- Fixed bottom bar (mobile-optimized)
- Sticky to safe area (notch support)
- 5 main sections: Home, Explore, Places, Chat, Profile
- Active indicator with glow effect

## 🌐 Responsive Design

- **Mobile**: Full-width, optimized touch targets
- **Tablet**: 2-column grids
- **Desktop**: 3-column grids with enhanced layouts
- Safe area support for notched devices
- Touch-friendly button sizes (minimum 48x48px)

## ♿ Accessibility

- Semantic HTML structure
- ARIA labels for icons
- Sufficient color contrast (gold on dark meets WCAG AA)
- Keyboard navigation support
- Focus visible states

## 🔐 Security

- No sensitive data stored (demo only)
- XSS protection via React
- CSRF ready for API integration
- Input validation ready

## 🚀 Performance

- Optimized images with lazy loading
- CSS transitions for smooth animations
- Minimal JavaScript bundle
- Efficient state management
- Component-level code splitting ready

## 🎭 Customization

### Changing Colors
Edit `client/global.css` CSS variables:
```css
:root {
  --primary: 43 100% 51%;  /* Gold */
  --secondary: 0 0% 12%;   /* Black */
  /* ... */
}
```

### Adding New Places
Update the `places` array in `client/pages/Index.tsx`:
```typescript
const places = [
  {
    id: 1,
    name: "Place Name",
    category: "Category",
    // ...
  },
];
```

### Extending Chat Suggestions
Modify `generateBotResponse()` in `client/pages/Chat.tsx`

## 📊 Data Structure

### Place Object
```typescript
interface Place {
  id: number;
  name: string;
  category: string;
  distance: string;
  rating: number;
  reviews: number;
  image: string;
  price: string;
  isFavorite: boolean;
}
```

### Chat Message Object
```typescript
interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}
```

## 🔄 State Management

Currently using React `useState` hooks. For scaling, consider:
- **Zustand** for simple global state
- **Redux** for complex state
- **Jotai** for atomic state
- **TanStack Query** for server state (already included)

## 📡 API Integration Ready

Hooks are prepared for API integration:
- Replace mock data in `useEffect` hooks
- Use TanStack Query for data fetching
- Update navigation URLs for API endpoints
- Implement authentication

## 🎬 Animation Details

### Fade In Up
```css
- Duration: 0.6s
- Easing: ease-out
- Staggered with 100ms delays per card
- Used on: Place cards, widgets
```

### Scale Hover
```css
- Scale: 1.05
- Translate: -4px (up)
- Duration: 0.3s
- Used on: Cards, buttons
```

### Pulse Gold
```css
- Effect: Glowing box-shadow
- Duration: 2s
- Loop: Infinite
- Used on: Floating button
```

## 🐛 Known Limitations

1. Mock data only (no backend integration)
2. Favorites not persisted (use localStorage for demo)
3. Chat responses are template-based
4. Images are external URLs (may fail if source unavailable)
5. No authentication system

## 🔮 Future Enhancements

- [ ] Backend API integration
- [ ] Real user authentication
- [ ] Interactive map view with Mapbox/Google Maps
- [ ] Real-time chat with LLM
- [ ] Voice search with STT/TTS
- [ ] Booking integration
- [ ] Payment processing
- [ ] Social sharing features
- [ ] Offline support with PWA
- [ ] Dark mode toggle
- [ ] Multi-language support

## 📱 Browser Support

- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS 14+, Android 10+)

## 📄 License

This project is built as a demonstration of modern web design and development practices. Feel free to use and modify for educational and commercial purposes.

## 👨‍💻 Development Notes

- Component-based architecture for scalability
- Tailwind utility-first CSS approach
- Type-safe TypeScript throughout
- Mobile-first responsive design
- Semantic HTML for accessibility
- Performance-optimized animations
- Clean, maintainable code structure

## 🙏 Credits

Built with ❤️ for the Egyptian web development community. Features inspired by modern discovery apps with Egyptian cultural aesthetics.

---

**خرجة** - Discover Egypt Your Way 🇪🇬✨
