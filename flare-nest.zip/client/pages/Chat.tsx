import { useState, useRef, useEffect } from "react";
import { Send, Mic, X } from "lucide-react";

export default function ChatPage() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "مرحباً! 👋 أنا مساعدك الذكي. كيف أساعدك في اختيار خروجة رائعة اليوم؟",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (text: string = input) => {
    if (!text.trim()) return;

    // Add user message
    const userMessage = {
      id: messages.length + 1,
      text: text,
      sender: "user",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // Simulate bot response delay
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Generate contextual response
    const botResponse = generateBotResponse(text);
    const botMessage = {
      id: messages.length + 2,
      text: botResponse,
      sender: "bot",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, botMessage]);
    setIsLoading(false);
  };

  const generateBotResponse = (userInput: string): string => {
    const input_lower = userInput.toLowerCase();

    if (
      input_lower.includes("رومانسي") ||
      input_lower.includes("غروب") ||
      input_lower.includes("نيل")
    ) {
      return "👌 فكرة رومانسية جميلة! أنصحك بكافيه النيل وقت الغروب، أو رحلة نيلية برفقة أحبائك. التجربة ساحرة! 🌅";
    } else if (
      input_lower.includes("مغامرة") ||
      input_lower.includes("رياضة")
    ) {
      return "⛰️ حماسة! عندنا خيارات رائعة: رحلات تسلق في الجبال، رياضات مائية، أو جولات دراجات هوائية. إيه رأيك؟";
    } else if (
      input_lower.includes("عائلي") ||
      input_lower.includes("أطفال")
    ) {
      return "👨‍👩‍👧‍👦 ممتاز! أنصح بحديقة الأزهر، دريم بارك، أو ملاهي المعادي. كلها آمنة وممتعة للعيلة!";
    } else if (
      input_lower.includes("ميزانية") ||
      input_lower.includes("اقتصادي")
    ) {
      return "💰 فاهم! عندك خيارات رائعة برخص عريض: خان الخليلي، المتحف المصري، حدائق عامة. كلها متعة بسعر مناسب!";
    } else if (
      input_lower.includes("متحف") ||
      input_lower.includes("ثقافي")
    ) {
      return "🏛️ عاشق الثقافة والتاريخ! أنصحك بالمتحف المصري، معبد الكرنك، أو مقبرة توت عنخ آمون. تاريخ فرعوني عظيم! 🌟";
    } else {
      return "👍 فهمت فكرتك. الحين أقدر أساعدك أحسن لو قلت لي: إيه المود بتاعك اليوم؟ (رومانسي، مغامرة، عائلي، تاريخي، أم حاجة تانية؟)";
    }
  };

  const quickSuggestions = [
    "رومانسي 😍",
    "مغامرة ⛰️",
    "عائلي 👨‍👩‍👧‍👦",
    "ميزانية منخفضة 💰",
  ];

  return (
    <div className="min-h-screen bg-gradient-egyptian flex flex-col">
      {/* Header */}
      <header className="bg-black/95 sticky top-0 z-40 px-6 py-4 border-b border-amber-500/20">
        <h1 className="text-2xl font-bold text-amber-500">مساعدك الذكي</h1>
        <p className="text-xs text-gray-400">هنا اختار لك أحسن خروجة 🎯</p>
      </header>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto px-6 py-8 space-y-6">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.sender === "user" ? "justify-end" : "justify-start"
            } animate-fade-in-up`}
          >
            <div
              className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${
                message.sender === "user"
                  ? "bg-amber-500 text-black font-semibold rounded-br-none"
                  : "bg-black/80 text-white border border-amber-500/30 rounded-bl-none"
              }`}
            >
              <p className="text-sm md:text-base leading-relaxed">
                {message.text}
              </p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-black/80 border border-amber-500/30 px-4 py-3 rounded-2xl rounded-bl-none">
              <div className="flex gap-2">
                <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce"></div>
                <div
                  className="w-2 h-2 rounded-full bg-amber-500 animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                ></div>
                <div
                  className="w-2 h-2 rounded-full bg-amber-500 animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestions */}
      {messages.length < 3 && !isLoading && (
        <div className="px-6 py-4 bg-black/5 border-y border-amber-500/10">
          <p className="text-xs text-gray-600 font-semibold mb-3">
            جرب أحد هذه الاقتراحات:
          </p>
          <div className="flex flex-wrap gap-2">
            {quickSuggestions.map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => handleSendMessage(suggestion)}
                className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-semibold text-amber-700 hover:bg-amber-500/20 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 px-6 py-4 pb-8">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter" && !isLoading) {
                handleSendMessage();
              }
            }}
            placeholder="اكتب ما يخطر ببالك..."
            className="flex-1 px-4 py-3 rounded-full border border-gray-300 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
            disabled={isLoading}
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !input.trim()}
            className="p-3 rounded-full bg-amber-500 hover:bg-amber-600 disabled:bg-gray-300 text-white transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
          <button className="p-3 rounded-full bg-black/10 hover:bg-black/20 text-gray-700 transition-colors">
            <Mic className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
