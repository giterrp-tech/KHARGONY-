import { useState } from "react";
import { Heart, Settings, LogOut, MapPin, Clock, Star } from "lucide-react";

export default function ProfilePage() {
  const [user, setUser] = useState({
    name: "محمد علي",
    email: "mohammad@example.com",
    phone: "+20 1012345678",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Mohammad",
    joinDate: "ديسمبر 2023",
    visits: 24,
    favorites: 12,
  });

  const favorites = [
    {
      id: 1,
      name: "الأهرامات وأبو الهول",
      category: "معالم تاريخية",
      savedDate: "قبل أسبوع",
    },
    {
      id: 2,
      name: "خان الخليلي",
      category: "أسواق تقليدية",
      savedDate: "قبل أسبوعين",
    },
    {
      id: 3,
      name: "المتحف المصري",
      category: "متاحف",
      savedDate: "قبل شهر",
    },
    {
      id: 4,
      name: "حديقة الأزهر",
      category: "حدائق",
      savedDate: "قبل شهرين",
    },
  ];

  const recentVisits = [
    {
      id: 1,
      name: "برج القاهرة",
      date: "أمس",
      rating: 4,
    },
    {
      id: 2,
      name: "كافيه النيل",
      date: "قبل يومين",
      rating: 5,
    },
    {
      id: 3,
      name: "شارع النيل",
      date: "قبل ثلاث أيام",
      rating: 4,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-egyptian pb-20">
      {/* Header */}
      <header className="bg-black/95 sticky top-0 z-40 px-6 py-4 border-b border-amber-500/20 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-amber-500">ملفي الشخصي</h1>
        <button className="p-2 hover:bg-amber-500/20 rounded-lg transition-colors">
          <Settings className="w-6 h-6 text-white" />
        </button>
      </header>

      <main className="px-6 py-8">
        {/* Profile Card */}
        <div className="mb-8 fade-in-up">
          <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8">
            <div className="flex items-center gap-6 mb-6">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-20 h-20 md:w-24 md:h-24 rounded-full border-4 border-amber-500"
              />
              <div className="flex-1">
                <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
                  {user.name}
                </h2>
                <p className="text-gray-600 text-sm">منذ {user.joinDate}</p>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-3 border-t border-gray-200 pt-6">
              <div className="flex items-center gap-3 text-gray-700">
                <span className="text-xl">📧</span>
                <span className="text-sm md:text-base">{user.email}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <span className="text-xl">📱</span>
                <span className="text-sm md:text-base">{user.phone}</span>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-gray-200">
              <div className="text-center">
                <p className="text-3xl font-bold text-amber-500">
                  {user.visits}
                </p>
                <p className="text-xs text-gray-600 mt-1">زيارة</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-amber-500">
                  {user.favorites}
                </p>
                <p className="text-xs text-gray-600 mt-1">مفضلة</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-amber-500">4.8</p>
                <p className="text-xs text-gray-600 mt-1">متوسط التقييم</p>
              </div>
            </div>

            {/* Edit Profile Button */}
            <button className="w-full mt-6 py-3 rounded-lg bg-amber-500 hover:bg-amber-600 text-black font-bold transition-colors">
              تعديل الملف الشخصي
            </button>
          </div>
        </div>

        {/* Preferences */}
        <div className="mb-8 fade-in-up" style={{ animationDelay: "100ms" }}>
          <h2 className="text-xl font-bold text-gray-900 mb-4">التفضيلات</h2>
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 font-semibold mb-2">
                  أنواع الأنش��ة المفضلة
                </p>
                <div className="flex flex-wrap gap-2">
                  {["رومانسي", "ثقافي", "عائلي"].map((activity) => (
                    <span
                      key={activity}
                      className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-sm font-semibold text-amber-700"
                    >
                      {activity}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600 font-semibold mb-2">
                  نطاق الميزانية المفضل
                </p>
                <p className="text-lg font-bold text-gray-900">متوسطة</p>
              </div>

              <div className="pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600 font-semibold mb-2">
                  اللغة
                </p>
                <p className="text-lg font-bold text-gray-900">العربية</p>
              </div>
            </div>
          </div>
        </div>

        {/* Favorites Section */}
        <div className="mb-8 fade-in-up" style={{ animationDelay: "200ms" }}>
          <h2 className="text-xl font-bold text-gray-900 mb-4">المفضلات</h2>
          <div className="space-y-3">
            {favorites.map((place) => (
              <div
                key={place.id}
                className="bg-white rounded-xl p-4 flex items-center justify-between hover:shadow-md transition-shadow"
              >
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{place.name}</h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {place.category} • {place.savedDate}
                  </p>
                </div>
                <Heart className="w-5 h-5 fill-amber-500 text-amber-500" />
              </div>
            ))}
          </div>
          <button className="w-full mt-4 py-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 font-semibold transition-colors border border-amber-500/30">
            عرض جميع المفضلات ({user.favorites})
          </button>
        </div>

        {/* Recent Visits */}
        <div className="mb-8 fade-in-up" style={{ animationDelay: "300ms" }}>
          <h2 className="text-xl font-bold text-gray-900 mb-4">آخر الزيارات</h2>
          <div className="space-y-3">
            {recentVisits.map((visit) => (
              <div
                key={visit.id}
                className="bg-white rounded-xl p-4 flex items-center justify-between"
              >
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{visit.name}</h3>
                  <p className="text-xs text-gray-500 mt-1">{visit.date}</p>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${
                        i < visit.rating
                          ? "fill-amber-500 text-amber-500"
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Settings and Logout */}
        <div className="space-y-3 fade-in-up" style={{ animationDelay: "400ms" }}>
          <button className="w-full py-3 rounded-lg bg-white hover:bg-gray-50 text-gray-900 font-semibold transition-colors flex items-center justify-center gap-2 border border-gray-200">
            <Settings className="w-5 h-5" />
            الإعدادات
          </button>
          <button className="w-full py-3 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 font-semibold transition-colors flex items-center justify-center gap-2 border border-red-500/30">
            <LogOut className="w-5 h-5" />
            تسجيل الخروج
          </button>
        </div>
      </main>
    </div>
  );
}
