import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Heart, MapPin, Star, Sparkles, ChevronDown } from "lucide-react";

export default function PlacesPage() {
  const navigate = useNavigate();
  const [scrollY, setScrollY] = useState(0);
  const [activeFilter, setActiveFilter] = useState("all");
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const places = [
    {
      id: 1,
      name: "الأهرامات وأبو الهول",
      category: "معالم تاريخية",
      distance: "15 كم",
      rating: 4.8,
      reviews: 2340,
      image: "https://images.unsplash.com/photo-1569163139394-de4798aa62b1?w=400&h=300&fit=crop",
      price: "متوسط",
      isFavorite: false,
    },
    {
      id: 2,
      name: "خان الخليلي",
      category: "أسواق تقليدية",
      distance: "3 كم",
      rating: 4.6,
      reviews: 1890,
      image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=300&fit=crop",
      price: "منخفض",
      isFavorite: false,
    },
    {
      id: 3,
      name: "المتحف المصري",
      category: "متاحف",
      distance: "2 كم",
      rating: 4.9,
      reviews: 3210,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
      price: "منخفض",
      isFavorite: false,
    },
    {
      id: 4,
      name: "برج القاهرة",
      category: "مناظر بانوراما",
      distance: "5 كم",
      rating: 4.5,
      reviews: 1650,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
      price: "مرتفع",
      isFavorite: false,
    },
    {
      id: 5,
      name: "حديقة الأزهر",
      category: "حدائق",
      distance: "4 كم",
      rating: 4.7,
      reviews: 1420,
      image: "https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=400&h=300&fit=crop",
      price: "منخفض",
      isFavorite: false,
    },
    {
      id: 6,
      name: "كافيه النيل",
      category: "مقاهي فاخرة",
      distance: "2 كم",
      rating: 4.4,
      reviews: 980,
      image: "https://images.unsplash.com/photo-1521017776416-ed444b0b94f5?w=400&h=300&fit=crop",
      price: "مرتفع",
      isFavorite: false,
    },
  ];

  const filters = [
    { id: "all", label: "ال��ل" },
    { id: "historic", label: "تاريخي" },
    { id: "food", label: "طعام" },
    { id: "nature", label: "طبيعة" },
    { id: "culture", label: "ثقافة" },
  ];

  const handlePullToRefresh = async () => {
    setIsRefreshing(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsRefreshing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-egyptian">
      {/* Header with Egyptian Theme */}
      <header className="egyptian-header sticky top-0 z-50 pb-4 pt-4">
        <div className="flex items-center justify-between px-6">
          <div className="flex flex-col">
            <h1 className="text-3xl font-bold gold-text tracking-wide">الأماكن</h1>
            <span className="text-xs text-gray-400">المقترحة 👑</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-semibold text-white">القاهرة</p>
              <p className="text-xs text-gray-300">26°C - غائم جزئياً</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center text-xl">
              ☁️
            </div>
          </div>
        </div>

        {/* Smart Filter Bar */}
        <div className="mt-6 px-6 pb-4 border-b border-amber-500/30">
          <div className="flex gap-2 overflow-x-auto pb-2 scroll-smooth">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-5 py-2 rounded-full font-semibold text-sm transition-all duration-300 whitespace-nowrap ${
                  activeFilter === filter.id
                    ? "bg-amber-500 text-black shadow-lg shadow-amber-500/30"
                    : "bg-black/30 text-amber-500 hover:bg-black/50"
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Pull to Refresh Indicator */}
      <div
        className={`flex justify-center py-4 transition-opacity duration-300 ${
          isRefreshing ? "opacity-100" : "opacity-0"
        }`}
      >
        {isRefreshing && (
          <div className="text-2xl animate-spin">👁️‍🗨️</div>
        )}
      </div>

      {/* Main Content */}
      <main className="px-4 py-8">
        {/* AI Recommendation Widget */}
        <div className="mb-10 fade-in-up">
          <div className="relative rounded-2xl overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 opacity-20 blur-xl"></div>
            <div className="relative bg-black/80 border-2 border-amber-500/50 rounded-2xl p-8 backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <Sparkles className="w-8 h-8 text-amber-500 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <p className="text-sm text-amber-500 font-semibold mb-2">💡 اقتراح ذكي</p>
                  <p className="text-white text-lg leading-relaxed">
                    بما إن المود بتاعك النهارده <span className="font-bold text-amber-400">رومانسي</span> 😍،
                    أرشحلك <span className="font-bold text-amber-400">كافيه على النيل</span> وقت الغروب 🌅
                  </p>
                </div>
              </div>
              {/* Egyptian Pattern Corners */}
              <div className="absolute top-3 right-3 text-2xl opacity-30">✦</div>
              <div className="absolute bottom-3 left-3 text-2xl opacity-30">✦</div>
            </div>
          </div>
        </div>

        {/* Places Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-24">
          {places.map((place, index) => (
            <PlaceCard
              key={place.id}
              place={place}
              index={index}
              onToggleFavorite={() => {}}
            />
          ))}
        </div>
      </main>

      {/* Floating Action Button */}
      <FloatingButton />
    </div>
  );
}

function PlaceCard({
  place,
  index,
  onToggleFavorite,
}: {
  place: (typeof places)[0];
  index: number;
  onToggleFavorite: () => void;
}) {
  const navigate = useNavigate();
  const [isFavorite, setIsFavorite] = useState(place.isFavorite);

  const animationDelay = index * 100;

  return (
    <div
      className="place-card fade-in-up cursor-pointer"
      style={{
        animationDelay: `${animationDelay}ms`,
        animationFillMode: "both",
      }}
      onClick={() => navigate(`/place/${place.id}`)}
    >
      {/* Image Section */}
      <div className="relative h-56 overflow-hidden bg-gray-200 group">
        <img
          src={place.image}
          alt={place.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />

        {/* Dark Overlay with Name */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>

        <div className="absolute inset-0 flex flex-col justify-between p-4">
          {/* Favorite Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsFavorite(!isFavorite);
            }}
            className="self-end p-2 rounded-full bg-black/40 hover:bg-amber-500/80 transition-colors"
          >
            <Heart
              className={`w-5 h-5 ${
                isFavorite ? "fill-current text-amber-500" : "text-white"
              }`}
            />
          </button>

          {/* Name and Category at Bottom */}
          <div>
            <h3 className="text-xl font-bold text-amber-400 mb-1">
              {place.name}
            </h3>
            <p className="text-xs text-gray-300">{place.category}</p>
          </div>
        </div>
      </div>

      {/* Details Section */}
      <div className="p-4">
        {/* Rating and Distance */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
            <span className="font-semibold text-sm text-gray-800">
              {place.rating}
            </span>
            <span className="text-xs text-gray-500">({place.reviews})</span>
          </div>
          <div className="flex items-center gap-1 text-gray-600">
            <MapPin className="w-3 h-3" />
            <span className="text-xs">{place.distance}</span>
          </div>
        </div>

        {/* Price Badge */}
        <div className="inline-block px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-semibold text-amber-600 mb-3">
          {place.price}
        </div>

        {/* CTA Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/place/${place.id}`);
          }}
          className="w-full mt-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-black font-semibold transition-colors text-sm"
        >
          عرض التفاصيل
        </button>
      </div>
    </div>
  );
}

function FloatingButton() {
  return (
    <button className="float-button group">
      <div className="text-2xl group-hover:animate-bounce">🏺</div>
      <div className="absolute -inset-1 bg-amber-500/20 rounded-full blur-lg group-hover:blur-xl transition-all duration-300 -z-10"></div>
    </button>
  );
}

// Sample places data type export
type PlaceType = typeof places[0];
export type { PlaceType };
