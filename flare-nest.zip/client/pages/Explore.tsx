import { useState } from "react";
import { Search, Filter, MapPin, Star, X } from "lucide-react";

export default function ExplorePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    category: "all",
    priceRange: "all",
    rating: "all",
    distance: "all",
  });

  const categories = [
    { id: "all", label: "الكل" },
    { id: "historic", label: "معالم تاريخية" },
    { id: "food", label: "مطاعم وكافيهات" },
    { id: "nature", label: "طبيعة وحدائق" },
    { id: "culture", label: "ثقافة وفنون" },
    { id: "shopping", label: "تسوق" },
  ];

  const priceRanges = [
    { id: "all", label: "جميع الأسعار" },
    { id: "low", label: "منخفضة (أقل من 100ج)" },
    { id: "medium", label: "متوسطة (100-300ج)" },
    { id: "high", label: "مرتفعة (أكثر من 300ج)" },
  ];

  const ratings = [
    { id: "all", label: "جميع التقييمات" },
    { id: "4.5", label: "4.5+ ⭐" },
    { id: "4", label: "4+ ⭐" },
    { id: "3", label: "3+ ⭐" },
  ];

  const distances = [
    { id: "all", label: "جميع المسافات" },
    { id: "near", label: "قريب (أقل من 5 كم)" },
    { id: "medium", label: "متوسط (5-15 كم)" },
    { id: "far", label: "بعيد (أكثر من 15 كم)" },
  ];

  const places = [
    {
      id: 1,
      name: "الأهرامات وأبو الهول",
      category: "معالم تاريخية",
      price: "متوسط",
      rating: 4.8,
      distance: "15 كم",
      image: "https://images.unsplash.com/photo-1569163139394-de4798aa62b1?w=400&h=300&fit=crop",
      reviews: 2340,
    },
    {
      id: 2,
      name: "خان الخليلي",
      category: "تسوق",
      price: "منخفض",
      rating: 4.6,
      distance: "3 كم",
      image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=300&fit=crop",
      reviews: 1890,
    },
    {
      id: 3,
      name: "المتحف المصري",
      category: "ثقافة وفنون",
      price: "منخفض",
      rating: 4.9,
      distance: "2 كم",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
      reviews: 3210,
    },
    {
      id: 4,
      name: "برج القاهرة",
      category: "معالم تاريخية",
      price: "مرتفع",
      rating: 4.5,
      distance: "5 كم",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
      reviews: 1650,
    },
    {
      id: 5,
      name: "حديقة الأزهر",
      category: "طبيعة وحدائق",
      price: "منخفض",
      rating: 4.7,
      distance: "4 كم",
      image: "https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=400&h=300&fit=crop",
      reviews: 1420,
    },
    {
      id: 6,
      name: "كافيه النيل",
      category: "مطاعم وكافيهات",
      price: "مرتفع",
      rating: 4.4,
      distance: "2 كم",
      image: "https://images.unsplash.com/photo-1521017776416-ed444b0b94f5?w=400&h=300&fit=crop",
      reviews: 980,
    },
  ];

  const filteredPlaces = places.filter((place) => {
    const matchesSearch = place.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesCategory =
      filters.category === "all" ||
      place.category.toLowerCase().includes(filters.category);
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-egyptian pb-20">
      {/* Header */}
      <header className="bg-black/95 sticky top-0 z-40 px-6 py-4 border-b border-amber-500/20">
        <h1 className="text-2xl font-bold text-amber-500 mb-4">استكشف</h1>

        {/* Search Bar */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مكان..."
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-white/10 border border-amber-500/30 text-white placeholder-gray-400 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-black font-semibold transition-colors flex items-center gap-2"
          >
            <Filter className="w-4 h-4" />
            <span className="hidden sm:inline">فلاتر</span>
          </button>
        </div>
      </header>

      {/* Filters Panel */}
      {showFilters && (
        <div className="bg-black/90 border-b border-amber-500/20 px-6 py-6">
          <div className="space-y-6">
            {/* Category Filter */}
            <div>
              <h3 className="text-sm font-bold text-amber-500 mb-3">الفئة</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() =>
                      setFilters({ ...filters, category: cat.id })
                    }
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                      filters.category === cat.id
                        ? "bg-amber-500 text-black"
                        : "bg-white/10 text-white hover:bg-white/20"
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Filter */}
            <div>
              <h3 className="text-sm font-bold text-amber-500 mb-3">السعر</h3>
              <div className="grid grid-cols-2 gap-2">
                {priceRanges.map((price) => (
                  <button
                    key={price.id}
                    onClick={() =>
                      setFilters({ ...filters, priceRange: price.id })
                    }
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                      filters.priceRange === price.id
                        ? "bg-amber-500 text-black"
                        : "bg-white/10 text-white hover:bg-white/20"
                    }`}
                  >
                    {price.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Rating Filter */}
            <div>
              <h3 className="text-sm font-bold text-amber-500 mb-3">التقييم</h3>
              <div className="grid grid-cols-2 gap-2">
                {ratings.map((rating) => (
                  <button
                    key={rating.id}
                    onClick={() =>
                      setFilters({ ...filters, rating: rating.id })
                    }
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                      filters.rating === rating.id
                        ? "bg-amber-500 text-black"
                        : "bg-white/10 text-white hover:bg-white/20"
                    }`}
                  >
                    {rating.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Distance Filter */}
            <div>
              <h3 className="text-sm font-bold text-amber-500 mb-3">المسافة</h3>
              <div className="grid grid-cols-2 gap-2">
                {distances.map((dist) => (
                  <button
                    key={dist.id}
                    onClick={() =>
                      setFilters({ ...filters, distance: dist.id })
                    }
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                      filters.distance === dist.id
                        ? "bg-amber-500 text-black"
                        : "bg-white/10 text-white hover:bg-white/20"
                    }`}
                  >
                    {dist.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={() => setShowFilters(false)}
              className="w-full py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-500 font-semibold transition-colors"
            >
              تم
            </button>
          </div>
        </div>
      )}

      {/* Results */}
      <main className="px-6 py-8">
        <p className="text-sm text-gray-600 mb-6">
          {filteredPlaces.length} مكان متطابق
        </p>

        {filteredPlaces.length > 0 ? (
          <div className="space-y-6">
            {filteredPlaces.map((place, index) => (
              <div
                key={place.id}
                className="fade-in-up rounded-xl overflow-hidden bg-white shadow-lg hover:shadow-xl transition-shadow"
                style={{
                  animationDelay: `${index * 50}ms`,
                  animationFillMode: "both",
                }}
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                  {/* Image */}
                  <div className="h-48 md:h-full bg-gray-300 overflow-hidden">
                    <img
                      src={place.image}
                      alt={place.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Content */}
                  <div className="md:col-span-2 p-4 md:p-6 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {place.name}
                      </h3>
                      <p className="text-sm text-gray-600 mb-3">
                        {place.category}
                      </p>

                      <div className="flex flex-wrap gap-4 mb-4">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                          <span className="font-semibold text-sm text-gray-800">
                            {place.rating}
                          </span>
                          <span className="text-xs text-gray-500">
                            ({place.reviews})
                          </span>
                        </div>

                        <div className="flex items-center gap-1 text-gray-600">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{place.distance}</span>
                        </div>

                        <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-xs font-semibold text-amber-700">
                          {place.price}
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button className="flex-1 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-black font-semibold transition-colors text-sm">
                        التفاصيل
                      </button>
                      <button className="px-4 py-2 rounded-lg bg-black/10 hover:bg-black/20 text-gray-900 font-semibold transition-colors text-sm">
                        🗺️
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-gray-600 mb-2">لم نجد نتائج</p>
            <p className="text-sm text-gray-500">
              جرب تغيير معايير البحث أ�� الفلاتر
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
