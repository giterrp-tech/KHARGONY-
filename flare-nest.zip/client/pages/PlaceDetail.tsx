import { ArrowLeft, Heart, MapPin, Clock, Phone, Share2, Star } from "lucide-react";
import { useState } from "react";

export default function PlaceDetail() {
  const [isFavorite, setIsFavorite] = useState(false);

  const place = {
    id: 1,
    name: "الأهرامات وأبو الهول",
    category: "معالم تاريخية",
    rating: 4.8,
    reviews: 2340,
    price: "متوسط",
    distance: "15 كم",
    address: "الهرم، الجيزة، مصر",
    phone: "+20 2 XXXX XXXX",
    hours: "08:00 - 17:00",
    description:
      "تُعتبر أهرامات الجيزة من أعظم العجائب المعمارية في التاريخ. شاهد القدرات الهندسية للحضارة المصرية القديمة وتعرف على تاريخ فرعوني عريق.",
    images: [
      "https://images.unsplash.com/photo-1569163139394-de4798aa62b1?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=800&h=600&fit=crop",
    ],
    activities: ["التصوير", "التعليم", "المشي"],
    bestTime: "الصباح الباكر أو العصر",
  };

  const reviews = [
    {
      id: 1,
      author: "فاطمة أحمد",
      rating: 5,
      text: "مكان رائع جداً! منظر خيالي وتاريخ عريق. يستحق الزيارة بكل تأكيد!",
      date: "قبل أسبوع",
    },
    {
      id: 2,
      author: "محمود علي",
      rating: 4,
      text: "جميل جداً لكن الازدحام شوية كتير. أنصح تروح الصباح بدري.",
      date: "قبل شهر",
    },
    {
      id: 3,
      author: "سارة محمد",
      rating: 5,
      text: "حقاً، عظمة وجمال الأهرامات بتأخد النفس. تجربة ما تنسى!",
      date: "قبل شهرين",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-egyptian pb-24">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-black/90 z-50 flex items-center justify-between px-6 py-4">
        <button className="p-2 hover:bg-amber-500/20 rounded-lg transition-colors">
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <h1 className="text-xl font-bold text-amber-500 flex-1 text-center px-4">
          التفاصيل
        </h1>
        <button className="p-2 hover:bg-amber-500/20 rounded-lg transition-colors">
          <Share2 className="w-6 h-6 text-white" />
        </button>
      </header>

      {/* Image Gallery */}
      <div className="mt-16 relative h-80 overflow-hidden bg-gray-300">
        <img
          src={place.images[0]}
          alt={place.name}
          className="w-full h-full object-cover"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-gradient-egyptian"></div>

        {/* Favorite Button */}
        <button
          onClick={() => setIsFavorite(!isFavorite)}
          className="absolute top-4 right-4 p-3 rounded-full bg-black/40 hover:bg-amber-500/80 transition-colors backdrop-blur-sm"
        >
          <Heart
            className={`w-6 h-6 ${
              isFavorite ? "fill-current text-amber-500" : "text-white"
            }`}
          />
        </button>

        {/* Image Counter */}
        <div className="absolute bottom-4 left-4 bg-black/60 px-3 py-1 rounded-full text-sm text-white">
          1 / {place.images.length}
        </div>
      </div>

      {/* Content */}
      <main className="px-6 py-8">
        {/* Title Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {place.name}
          </h1>
          <p className="text-amber-600 font-semibold mb-4">{place.category}</p>

          {/* Rating and Price */}
          <div className="flex items-center gap-6 mb-4">
            <div className="flex items-center gap-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(place.rating)
                        ? "fill-amber-500 text-amber-500"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="font-semibold text-gray-800">
                {place.rating}
              </span>
              <span className="text-sm text-gray-500">
                ({place.reviews} تقييم)
              </span>
            </div>
            <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-sm font-semibold text-amber-700">
              {place.price}
            </div>
          </div>
        </div>

        {/* Key Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 p-4 bg-black/5 rounded-xl border border-amber-500/10">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
            <div>
              <p className="text-xs text-gray-600 font-semibold">العنوان</p>
              <p className="text-sm text-gray-800">{place.address}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
            <div>
              <p className="text-xs text-gray-600 font-semibold">ساعات العمل</p>
              <p className="text-sm text-gray-800">{place.hours}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Phone className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
            <div>
              <p className="text-xs text-gray-600 font-semibold">الهاتف</p>
              <p className="text-sm text-gray-800 hover:text-amber-600 cursor-pointer">
                {place.phone}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
            <div>
              <p className="text-xs text-gray-600 font-semibold">أفضل وقت</p>
              <p className="text-sm text-gray-800">{place.bestTime}</p>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-3">نبذة</h2>
          <p className="text-gray-700 leading-relaxed text-sm md:text-base">
            {place.description}
          </p>
        </div>

        {/* Activities */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-3">الأنشطة المتاحة</h2>
          <div className="flex flex-wrap gap-2">
            {place.activities.map((activity) => (
              <span
                key={activity}
                className="px-4 py-2 bg-amber-500/10 border border-amber-500/30 rounded-full text-sm font-semibold text-amber-700"
              >
                {activity}
              </span>
            ))}
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            التقييمات ({reviews.length})
          </h2>
          <div className="space-y-4">
            {reviews.map((review) => (
              <div
                key={review.id}
                className="p-4 bg-white rounded-xl border border-gray-200 hover:border-amber-500/30 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {review.author}
                    </h3>
                    <p className="text-xs text-gray-500">{review.date}</p>
                  </div>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < review.rating
                            ? "fill-amber-500 text-amber-500"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-gray-700">{review.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
          <button className="py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-black font-bold transition-colors shadow-lg">
            احجز الآن
          </button>
          <button className="py-3 rounded-xl bg-black/10 hover:bg-black/20 text-gray-900 font-bold transition-colors border border-gray-300">
            الاتجاهات 🗺️
          </button>
        </div>
      </main>
    </div>
  );
}
