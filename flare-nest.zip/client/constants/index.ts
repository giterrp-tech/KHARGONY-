/**
 * Application Constants and Configuration
 * Centralized place for all app-wide constants
 */

/**
 * App Information
 */
export const APP_INFO = {
  name: "خرجة",
  description: "اكتشف مصر بطريقتك",
  version: "1.0.0",
  author: "Khrga Team",
  year: 2024,
} as const;

/**
 * API Configuration
 */
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_URL || "http://localhost:3000/api",
  TIMEOUT: 30000,
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000,
} as const;

/**
 * Route Paths
 */
export const ROUTES = {
  HOME: "/",
  PLACES: "/places",
  PLACE_DETAIL: (id: number | string) => `/place/${id}`,
  EXPLORE: "/explore",
  CHAT: "/chat",
  PROFILE: "/profile",
  NOT_FOUND: "*",
} as const;

/**
 * Place Categories
 */
export const PLACE_CATEGORIES = [
  { id: "all", label: "الكل" },
  { id: "معالم تاريخية", label: "معالم تاريخية" },
  { id: "أسواق تقليدية", label: "أسواق تقليدية" },
  { id: "متاحف", label: "متاحف" },
  { id: "مناظر بانوراما", label: "مناظر بانوراما" },
  { id: "حدائق", label: "حدائق" },
  { id: "مقاهي فاخرة", label: "مقاهي فاخرة" },
  { id: "مطاعم", label: "مطاعم" },
  { id: "شواطئ", label: "شواطئ" },
  { id: "منتزهات", label: "منتزهات" },
] as const;

/**
 * Price Levels
 */
export const PRICE_LEVELS = [
  { id: "all", label: "جميع الأسعار" },
  { id: "منخفض", label: "منخفض (أقل من 100ج)" },
  { id: "متوسط", label: "متوسط (100-300ج)" },
  { id: "مرتفع", label: "مرتفع (أكثر من 300ج)" },
] as const;

/**
 * Rating Options
 */
export const RATING_OPTIONS = [
  { id: "all", label: "جميع التقييمات" },
  { id: "4.5", label: "4.5+ ⭐" },
  { id: "4", label: "4+ ⭐" },
  { id: "3", label: "3+ ⭐" },
] as const;

/**
 * Distance Options
 */
export const DISTANCE_OPTIONS = [
  { id: "all", label: "جميع المسافات" },
  { id: "near", label: "قريب (أقل من 5 كم)" },
  { id: "medium", label: "متوسط (5-15 كم)" },
  { id: "far", label: "بعيد (أكثر من 15 كم)" },
] as const;

/**
 * User Moods
 */
export const USER_MOODS = [
  { id: "رومانسي", emoji: "😍", label: "رومانسي" },
  { id: "مغامرة", emoji: "⛰️", label: "مغامرة" },
  { id: "عائلي", emoji: "👨‍👩‍👧‍👦", label: "عائلي" },
  { id: "هادي", emoji: "😌", label: "هادي" },
  { id: "ثقافي", emoji: "🏛️", label: "ثقافي" },
] as const;

/**
 * Activities
 */
export const ACTIVITIES = [
  "التصوير",
  "التعليم",
  "المشي",
  "السباحة",
  "الاسترخاء",
  "التسوق",
  "تناول الطعام",
  "المغامرة",
  "المشاهدة",
  "القراءة",
] as const;

/**
 * Languages
 */
export const LANGUAGES = [
  { code: "ar", label: "العربية" },
  { code: "en", label: "English" },
] as const;

/**
 * Color Tokens
 */
export const COLORS = {
  primary: "#D4AF37", // Gold
  secondary: "#000000", // Black
  background: "#F9F6F0", // Cream
  white: "#FFFFFF",
  tan: "#E8DCC4",
  error: "#EF4444",
  success: "#10B981",
  warning: "#F59E0B",
  info: "#3B82F6",
} as const;

/**
 * Animation Durations (ms)
 */
export const ANIMATION_DURATIONS = {
  fast: 150,
  normal: 300,
  slow: 500,
  slower: 700,
  slowest: 1000,
} as const;

/**
 * Pagination
 */
export const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 20,
  MAX_LIMIT: 100,
} as const;

/**
 * Validation Rules
 */
export const VALIDATION = {
  EMAIL_REGEX: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  PHONE_REGEX: /^(\+?20)?[0-9]{10}$/,
  PASSWORD_MIN_LENGTH: 8,
  NAME_MIN_LENGTH: 2,
  NAME_MAX_LENGTH: 50,
  DESCRIPTION_MAX_LENGTH: 1000,
} as const;

/**
 * Storage Keys
 */
export const STORAGE_KEYS = {
  FAVORITES: "khrga_favorites",
  HISTORY: "khrga_history",
  PREFERENCES: "khrga_preferences",
  LAST_VISIT: "khrga_last_visit",
  USER: "khrga_user",
  AUTH_TOKEN: "khrga_auth_token",
} as const;

/**
 * Cache Durations (ms)
 */
export const CACHE_DURATIONS = {
  SHORT: 5 * 60 * 1000, // 5 minutes
  MEDIUM: 30 * 60 * 1000, // 30 minutes
  LONG: 60 * 60 * 1000, // 1 hour
  VERY_LONG: 24 * 60 * 60 * 1000, // 1 day
} as const;

/**
 * Navigation Items
 */
export const NAV_ITEMS = [
  { path: "/", icon: "🏠", label: "الرئيسية" },
  { path: "/explore", icon: "🔍", label: "است��شاف" },
  { path: "/places", icon: "📍", label: "الأماكن" },
  { path: "/chat", icon: "💬", label: "شات" },
  { path: "/profile", icon: "👤", label: "ملفي" },
] as const;

/**
 * Empty State Messages
 */
export const EMPTY_STATES = {
  NO_RESULTS: "لم نجد نتائج",
  NO_FAVORITES: "لم تضف أي أماكن للمفضلة بعد",
  NO_HISTORY: "لم تزر أي أماكن بعد",
  NO_MESSAGES: "لا توجد رسائل",
  SOMETHING_WRONG: "حدث خطأ ما",
} as const;

/**
 * Error Messages
 */
export const ERROR_MESSAGES = {
  NETWORK_ERROR: "فشل الاتصال بالخادم",
  INVALID_EMAIL: "البريد الإلكتروني غير صحيح",
  INVALID_PASSWORD: "كلمة المرور غير صحيحة",
  INVALID_PHONE: "رقم الهاتف غير صحيح",
  SOMETHING_WENT_WRONG: "حدث خطأ ما",
  PLEASE_TRY_AGAIN: "الرجاء المحاولة لاحقاً",
  NOT_FOUND: "لم يتم العثور على المورد",
  UNAUTHORIZED: "غير مصرح",
  FORBIDDEN: "الوصول مرفوض",
  SERVER_ERROR: "خطأ في الخادم",
} as const;

/**
 * Success Messages
 */
export const SUCCESS_MESSAGES = {
  SAVED: "تم الحفظ بنجاح",
  DELETED: "تم الحذف بنجاح",
  UPDATED: "تم التحديث بنجاح",
  CREATED: "تم الإنشاء بنجاح",
  LOGIN_SUCCESS: "تم تسجيل الدخول بنجاح",
  LOGOUT_SUCCESS: "تم تسجيل الخروج بنجاح",
  ADDED_TO_FAVORITES: "تمت الإضافة للمفضلة",
  REMOVED_FROM_FAVORITES: "تمت الإزالة من المفضلة",
} as const;

/**
 * Feature Flags
 */
export const FEATURE_FLAGS = {
  ENABLE_ANALYTICS: true,
  ENABLE_ERROR_TRACKING: true,
  ENABLE_NOTIFICATIONS: true,
  ENABLE_VOICE_SEARCH: false,
  ENABLE_OFFLINE_MODE: false,
  ENABLE_DARK_MODE: true,
  MAINTENANCE_MODE: false,
} as const;

/**
 * API Endpoints
 */
export const API_ENDPOINTS = {
  PLACES: "/places",
  PLACE_DETAIL: (id: string | number) => `/places/${id}`,
  SEARCH: "/places/search",
  RECOMMENDATIONS: "/recommendations",
  CHAT: "/chat",
  AUTH_LOGIN: "/auth/login",
  AUTH_REGISTER: "/auth/register",
  AUTH_LOGOUT: "/auth/logout",
  USER_PROFILE: "/user/profile",
  USER_PREFERENCES: "/user/preferences",
  FAVORITES: "/favorites",
  HISTORY: "/history",
} as const;

/**
 * HTTP Status Codes
 */
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
} as const;

/**
 * Date Formats
 */
export const DATE_FORMATS = {
  SHORT: "dd/MM/yyyy",
  LONG: "dd MMMM yyyy",
  TIME: "HH:mm",
  DATE_TIME: "dd/MM/yyyy HH:mm",
} as const;

/**
 * Breakpoints
 */
export const BREAKPOINTS = {
  XS: 320,
  SM: 640,
  MD: 768,
  LG: 1024,
  XL: 1280,
  "2XL": 1536,
} as const;

/**
 * Z-Index Scale
 */
export const Z_INDEX = {
  HIDDEN: -1,
  BASE: 0,
  DROPDOWN: 100,
  STICKY: 200,
  FIXED: 300,
  MODAL_BACKDROP: 400,
  MODAL: 500,
  POPOVER: 600,
  TOOLTIP: 700,
  NOTIFICATION: 800,
  FLOATING_BUTTON: 900,
} as const;

/**
 * Debounce Delays (ms)
 */
export const DEBOUNCE_DELAYS = {
  SEARCH: 300,
  RESIZE: 500,
  SCROLL: 200,
  INPUT: 300,
} as const;

/**
 * Default Page Titles
 */
export const PAGE_TITLES = {
  HOME: "الرئيسية - خرجة",
  EXPLORE: "استكشاف - خرجة",
  PLACES: "الأماكن - خرجة",
  CHAT: "الشات - خرجة",
  PROFILE: "ملفي - خرجة",
  NOT_FOUND: "الصفحة غير موجودة - خرجة",
} as const;

/**
 * Social Links (for future use)
 */
export const SOCIAL_LINKS = {
  FACEBOOK: "https://facebook.com/khrga",
  INSTAGRAM: "https://instagram.com/khrga",
  TWITTER: "https://twitter.com/khrga",
  TIKTOK: "https://tiktok.com/@khrga",
} as const;

/**
 * Contact Information
 */
export const CONTACT_INFO = {
  EMAIL: "info@khrga.app",
  PHONE: "+20 XXX XXXX XXX",
  WEBSITE: "https://khrga.app",
  SUPPORT_EMAIL: "support@khrga.app",
} as const;
