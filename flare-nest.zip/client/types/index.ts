/**
 * Type definitions for Khrga App
 * Central location for all TypeScript interfaces and types
 */

/**
 * Place Interface - Represents a place in Egypt
 */
export interface Place {
  id: number;
  name: string;
  category: PlaceCategory;
  description?: string;
  distance: string;
  distanceKm?: number;
  rating: number;
  reviews: number;
  image: string;
  images?: string[];
  price: PriceLevel;
  isFavorite: boolean;
  latitude?: number;
  longitude?: number;
  address?: string;
  phone?: string;
  hours?: string;
  website?: string;
  tags?: string[];
  activities?: Activity[];
  bestTime?: string;
}

/**
 * Place Categories
 */
export type PlaceCategory =
  | "معالم تاريخية"
  | "أسواق تقليدية"
  | "متاحف"
  | "مناظر بانوراما"
  | "حدائق"
  | "مقاهي فاخرة"
  | "مطاعم"
  | "شواطئ"
  | "منتزهات";

/**
 * Price Levels
 */
export type PriceLevel = "منخفض" | "متوسط" | "مرتفع";

/**
 * Activities available at a place
 */
export type Activity =
  | "التصوير"
  | "التعليم"
  | "المشي"
  | "السباحة"
  | "الاسترخاء"
  | "التسوق"
  | "تناول الطعام"
  | "المغامرة";

/**
 * User Mood/Preference Types
 */
export type UserMood = "رومانسي" | "مغامرة" | "عائلي" | "هادي" | "ثقافي";

/**
 * Chat Message
 */
export interface ChatMessage {
  id: number;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
  suggestedPlaces?: Place[];
}

/**
 * User Profile
 */
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  joinDate: Date;
  preferences: UserPreferences;
  stats: UserStats;
}

/**
 * User Preferences
 */
export interface UserPreferences {
  budget: PriceLevel;
  favoriteActivities: Activity[];
  language: "ar" | "en";
  darkMode: boolean;
  notificationsEnabled: boolean;
  shareLocation: boolean;
}

/**
 * User Statistics
 */
export interface UserStats {
  totalVisits: number;
  uniquePlaces: number;
  totalFavorites: number;
  averageRating: number;
  lastVisitDate?: Date;
}

/**
 * Filter Options
 */
export interface FilterOptions {
  category?: PlaceCategory;
  priceRange?: PriceLevel | "الكل";
  rating?: number | "الكل";
  distance?: string;
  search?: string;
}

/**
 * Review
 */
export interface Review {
  id: number;
  author: string;
  rating: number;
  text: string;
  date: string;
  avatar?: string;
}

/**
 * Location Coordinates
 */
export interface Location {
  latitude: number;
  longitude: number;
  address?: string;
}

/**
 * Weather Data
 */
export interface WeatherData {
  temperature: number;
  condition: "sunny" | "cloudy" | "rainy" | "snowy";
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

/**
 * API Response Types
 */
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

/**
 * Pagination
 */
export interface PaginationParams {
  page: number;
  limit: number;
  offset: number;
}

/**
 * Search Result
 */
export interface SearchResult {
  places: Place[];
  total: number;
  page: number;
  hasMore: boolean;
}

/**
 * Recommendation
 */
export interface Recommendation {
  place: Place;
  score: number;
  reason: "trending" | "based_on_history" | "weather_match" | "nearby";
}

/**
 * Event
 */
export interface Event {
  id: number;
  title: string;
  description?: string;
  startDate: Date;
  endDate?: Date;
  location: string;
  image?: string;
  category?: string;
  ticketPrice?: number;
  bookingUrl?: string;
}

/**
 * Navigation Item
 */
export interface NavItem {
  path: string;
  icon: string;
  label: string;
  active?: boolean;
}

/**
 * Error Type
 */
export interface AppError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  timestamp: Date;
}

/**
 * Loading State
 */
export interface LoadingState {
  isLoading: boolean;
  error?: AppError;
  data?: unknown;
}

/**
 * Form Data Types
 */
export interface LoginFormData {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterFormData {
  name: string;
  email: string;
  phone?: string;
  password: string;
  confirmPassword: string;
  termsAccepted: boolean;
}

export interface ProfileUpdateFormData {
  name?: string;
  email?: string;
  phone?: string;
  avatar?: string;
  preferences?: Partial<UserPreferences>;
}

/**
 * Filter Preset
 */
export interface FilterPreset {
  id: string;
  name: string;
  filters: FilterOptions;
}

/**
 * Notification
 */
export interface Notification {
  id: string;
  type: "success" | "error" | "info" | "warning";
  message: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

/**
 * Analytics Event
 */
export interface AnalyticsEvent {
  name: string;
  category: string;
  label?: string;
  value?: number;
  timestamp: Date;
  userId?: string;
}

/**
 * Cache Entry
 */
export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiresIn: number;
}
