import { useLocation, useNavigate } from "react-router-dom";

export function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { path: "/", icon: "🏠", label: "الرئيسية" },
    { path: "/explore", icon: "🔍", label: "استكشاف" },
    { path: "/places", icon: "📍", label: "الأماكن" },
    { path: "/chat", icon: "💬", label: "شات" },
    { path: "/profile", icon: "👤", label: "ملفي" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-gray-200 py-3 px-6 z-40 safe-area-inset-bottom">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive =
            location.pathname === item.path ||
            (item.path === "/places" && location.pathname === "/");

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all duration-300 ${
                isActive
                  ? "text-amber-500 scale-110"
                  : "text-gray-600 hover:text-amber-400"
              }`}
            >
              <span className="text-2xl">{item.icon}</span>
              <span
                className={`text-xs font-semibold ${
                  isActive ? "text-amber-500" : ""
                }`}
              >
                {item.label}
              </span>
              {isActive && (
                <div className="h-1 w-6 bg-amber-500 rounded-full animate-pulse-gold"></div>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
