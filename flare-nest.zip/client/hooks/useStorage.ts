/**
 * Custom React hooks for localStorage management
 * Provides reactive access to stored data with automatic synchronization
 */

import { useState, useEffect, useCallback } from "react";
import {
  favoritesStorage,
  historyStorage,
  preferencesStorage,
  sessionStorage,
} from "@/lib/storage";

/**
 * Hook to manage favorite places
 * @param placeId - The ID of the place to track (optional)
 * @returns { isFavorite, toggleFavorite, favorites, addFavorite, removeFavorite }
 */
export function useFavorites(placeId?: number) {
  const [favorites, setFavorites] = useState<number[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);

  // Initialize from localStorage
  useEffect(() => {
    const stored = favoritesStorage.getFavorites();
    setFavorites(stored);
    if (placeId !== undefined) {
      setIsFavorite(stored.includes(placeId));
    }
  }, [placeId]);

  const toggleFavorite = useCallback(
    (id: number = placeId) => {
      if (id === undefined) return;
      const newStatus = favoritesStorage.toggleFavorite(id);
      setFavorites(favoritesStorage.getFavorites());
      if (placeId === id) {
        setIsFavorite(newStatus);
      }
      return newStatus;
    },
    [placeId]
  );

  const addFavorite = useCallback((id: number) => {
    favoritesStorage.addFavorite(id);
    setFavorites(favoritesStorage.getFavorites());
    if (placeId === id) {
      setIsFavorite(true);
    }
  }, [placeId]);

  const removeFavorite = useCallback((id: number) => {
    favoritesStorage.removeFavorite(id);
    setFavorites(favoritesStorage.getFavorites());
    if (placeId === id) {
      setIsFavorite(false);
    }
  }, [placeId]);

  return {
    isFavorite,
    toggleFavorite,
    favorites,
    addFavorite,
    removeFavorite,
  };
}

/**
 * Hook to manage visit history
 * @returns { history, recentVisits, addVisit, stats, clearHistory }
 */
export function useHistory() {
  const [history, setHistory] = useState<
    Array<{
      placeId: number;
      placeName: string;
      timestamp: number;
      rating?: number;
    }>
  >([]);
  const [stats, setStats] = useState({
    totalVisits: 0,
    uniquePlaces: 0,
    lastVisitDate: undefined as Date | undefined,
  });

  // Initialize from localStorage
  useEffect(() => {
    const stored = historyStorage.getHistory();
    setHistory(stored);
    const calculatedStats = historyStorage.getStats();
    setStats(calculatedStats);
  }, []);

  const addVisit = useCallback(
    (placeId: number, placeName: string, rating?: number) => {
      historyStorage.addVisit(placeId, placeName, rating);
      setHistory(historyStorage.getHistory());
      setStats(historyStorage.getStats());
    },
    []
  );

  const recentVisits = useCallback(
    (count: number = 10) => {
      return historyStorage.getRecentVisits(count);
    },
    []
  );

  const clearHistory = useCallback(() => {
    historyStorage.clearHistory();
    setHistory([]);
    setStats({
      totalVisits: 0,
      uniquePlaces: 0,
      lastVisitDate: undefined,
    });
  }, []);

  return {
    history,
    recentVisits,
    addVisit,
    stats,
    clearHistory,
  };
}

/**
 * Hook to manage user preferences
 * @returns { preferences, updatePreferences, setBudget, setLanguage, toggleDarkMode }
 */
export function usePreferences() {
  const [preferences, setPreferences] = useState({
    budget: "medium" as "low" | "medium" | "high",
    favoriteActivities: [] as string[],
    language: "ar" as "ar" | "en",
    darkMode: false,
  });

  // Initialize from localStorage
  useEffect(() => {
    const stored = preferencesStorage.getPreferences();
    setPreferences(stored);
  }, []);

  const updatePreferences = useCallback(
    (updates: Partial<typeof preferences>) => {
      preferencesStorage.updatePreferences(updates);
      setPreferences((prev) => ({ ...prev, ...updates }));
    },
    []
  );

  const setBudget = useCallback(
    (budget: "low" | "medium" | "high") => {
      updatePreferences({ budget });
    },
    [updatePreferences]
  );

  const setLanguage = useCallback(
    (language: "ar" | "en") => {
      updatePreferences({ language });
    },
    [updatePreferences]
  );

  const toggleDarkMode = useCallback(() => {
    const newMode = !preferences.darkMode;
    updatePreferences({ darkMode: newMode });
    return newMode;
  }, [preferences.darkMode, updatePreferences]);

  return {
    preferences,
    updatePreferences,
    setBudget,
    setLanguage,
    toggleDarkMode,
  };
}

/**
 * Hook to track session
 * @returns { recordVisit, getLastVisit }
 */
export function useSession() {
  const recordVisit = useCallback(() => {
    sessionStorage.recordLastVisit();
  }, []);

  const getLastVisit = useCallback(() => {
    return sessionStorage.getLastVisit();
  }, []);

  return {
    recordVisit,
    getLastVisit,
  };
}

/**
 * Hook to get comprehensive user data
 * Combines favorites, history, and preferences
 */
export function useUserData() {
  const favoritesData = useFavorites();
  const historyData = useHistory();
  const preferencesData = usePreferences();

  return {
    favorites: favoritesData,
    history: historyData,
    preferences: preferencesData,
  };
}
