/**
 * LocalStorage utilities for persisting user data
 * Handles favorites, visit history, and preferences
 */

interface UserPreferences {
  budget: "low" | "medium" | "high";
  favoriteActivities: string[];
  language: "ar" | "en";
  darkMode: boolean;
}

interface VisitRecord {
  placeId: number;
  placeName: string;
  timestamp: number;
  rating?: number;
}

const STORAGE_KEYS = {
  FAVORITES: "khrga_favorites",
  HISTORY: "khrga_history",
  PREFERENCES: "khrga_preferences",
  LAST_VISIT: "khrga_last_visit",
};

/**
 * Favorites Management
 */
export const favoritesStorage = {
  /**
   * Get all favorite place IDs
   */
  getFavorites(): number[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error reading favorites:", error);
      return [];
    }
  },

  /**
   * Add a place to favorites
   */
  addFavorite(placeId: number): void {
    try {
      const favorites = this.getFavorites();
      if (!favorites.includes(placeId)) {
        favorites.push(placeId);
        localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favorites));
      }
    } catch (error) {
      console.error("Error adding favorite:", error);
    }
  },

  /**
   * Remove a place from favorites
   */
  removeFavorite(placeId: number): void {
    try {
      const favorites = this.getFavorites();
      const filtered = favorites.filter((id) => id !== placeId);
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(filtered));
    } catch (error) {
      console.error("Error removing favorite:", error);
    }
  },

  /**
   * Check if a place is favorited
   */
  isFavorite(placeId: number): boolean {
    return this.getFavorites().includes(placeId);
  },

  /**
   * Toggle favorite status
   */
  toggleFavorite(placeId: number): boolean {
    if (this.isFavorite(placeId)) {
      this.removeFavorite(placeId);
      return false;
    } else {
      this.addFavorite(placeId);
      return true;
    }
  },

  /**
   * Clear all favorites
   */
  clearFavorites(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.FAVORITES);
    } catch (error) {
      console.error("Error clearing favorites:", error);
    }
  },
};

/**
 * Visit History Management
 */
export const historyStorage = {
  /**
   * Get visit history
   */
  getHistory(): VisitRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.HISTORY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error reading history:", error);
      return [];
    }
  },

  /**
   * Add a visit to history
   */
  addVisit(
    placeId: number,
    placeName: string,
    rating?: number
  ): void {
    try {
      const history = this.getHistory();
      const visit: VisitRecord = {
        placeId,
        placeName,
        timestamp: Date.now(),
        rating,
      };
      history.unshift(visit); // Add to beginning
      // Keep only last 50 visits
      const limited = history.slice(0, 50);
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(limited));
    } catch (error) {
      console.error("Error adding visit:", error);
    }
  },

  /**
   * Get recent visits (last N visits)
   */
  getRecentVisits(count: number = 10): VisitRecord[] {
    return this.getHistory().slice(0, count);
  },

  /**
   * Get visit count for a specific place
   */
  getVisitCount(placeId: number): number {
    return this.getHistory().filter((v) => v.placeId === placeId).length;
  },

  /**
   * Clear all history
   */
  clearHistory(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.HISTORY);
    } catch (error) {
      console.error("Error clearing history:", error);
    }
  },

  /**
   * Get statistics
   */
  getStats(): {
    totalVisits: number;
    uniquePlaces: number;
    lastVisitDate?: Date;
  } {
    const history = this.getHistory();
    const uniquePlaces = new Set(history.map((v) => v.placeId)).size;
    const lastVisit = history[0]?.timestamp;

    return {
      totalVisits: history.length,
      uniquePlaces,
      lastVisitDate: lastVisit ? new Date(lastVisit) : undefined,
    };
  },
};

/**
 * Preferences Management
 */
export const preferencesStorage = {
  /**
   * Get user preferences
   */
  getPreferences(): UserPreferences {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
      return data
        ? JSON.parse(data)
        : {
            budget: "medium",
            favoriteActivities: [],
            language: "ar",
            darkMode: false,
          };
    } catch (error) {
      console.error("Error reading preferences:", error);
      return {
        budget: "medium",
        favoriteActivities: [],
        language: "ar",
        darkMode: false,
      };
    }
  },

  /**
   * Update preferences
   */
  updatePreferences(
    updates: Partial<UserPreferences>
  ): void {
    try {
      const current = this.getPreferences();
      const updated = { ...current, ...updates };
      localStorage.setItem(STORAGE_KEYS.PREFERENCES, JSON.stringify(updated));
    } catch (error) {
      console.error("Error updating preferences:", error);
    }
  },

  /**
   * Set budget preference
   */
  setBudget(budget: "low" | "medium" | "high"): void {
    this.updatePreferences({ budget });
  },

  /**
   * Update favorite activities
   */
  setFavoriteActivities(activities: string[]): void {
    this.updatePreferences({ favoriteActivities: activities });
  },

  /**
   * Toggle dark mode
   */
  toggleDarkMode(): boolean {
    const current = this.getPreferences();
    const newMode = !current.darkMode;
    this.updatePreferences({ darkMode: newMode });
    return newMode;
  },

  /**
   * Set language
   */
  setLanguage(language: "ar" | "en"): void {
    this.updatePreferences({ language });
  },

  /**
   * Reset to defaults
   */
  reset(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.PREFERENCES);
    } catch (error) {
      console.error("Error resetting preferences:", error);
    }
  },
};

/**
 * Session Management
 */
export const sessionStorage = {
  /**
   * Record last visit time
   */
  recordLastVisit(): void {
    try {
      localStorage.setItem(STORAGE_KEYS.LAST_VISIT, new Date().toISOString());
    } catch (error) {
      console.error("Error recording last visit:", error);
    }
  },

  /**
   * Get last visit time
   */
  getLastVisit(): Date | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.LAST_VISIT);
      return data ? new Date(data) : null;
    } catch (error) {
      console.error("Error getting last visit:", error);
      return null;
    }
  },

  /**
   * Clear all data
   */
  clearAllData(): void {
    try {
      Object.values(STORAGE_KEYS).forEach((key) => {
        localStorage.removeItem(key);
      });
    } catch (error) {
      console.error("Error clearing all data:", error);
    }
  },

  /**
   * Export all user data
   */
  exportData(): object {
    return {
      favorites: favoritesStorage.getFavorites(),
      history: historyStorage.getHistory(),
      preferences: preferencesStorage.getPreferences(),
      lastVisit: this.getLastVisit(),
    };
  },
};

/**
 * Debug utilities
 */
export const debugStorage = {
  /**
   * Log all stored data
   */
  logAll(): void {
    console.log("=== Khrga Storage Debug ===");
    console.log("Favorites:", favoritesStorage.getFavorites());
    console.log("History:", historyStorage.getHistory());
    console.log("Preferences:", preferencesStorage.getPreferences());
    console.log("Last Visit:", sessionStorage.getLastVisit());
    console.log("Stats:", historyStorage.getStats());
  },

  /**
   * Clear all data for testing
   */
  reset(): void {
    sessionStorage.clearAllData();
    console.log("All data cleared");
  },
};
